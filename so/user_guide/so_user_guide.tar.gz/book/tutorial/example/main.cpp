#include <iostream>

#include "lib.h"

int main() {
	std::cout << lib::add_two(40) << std::endl;
	return 0;
}
