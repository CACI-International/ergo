#ifndef _LIB_H_
#define _LIB_H_

namespace lib {
int add_two(int);
}

#endif
