namespace lib {

int add_two(int v) {
	return v + 2;
}

}
